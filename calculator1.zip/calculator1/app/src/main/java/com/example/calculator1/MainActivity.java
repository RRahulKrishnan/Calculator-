package com.example.calculator1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText num1, num2;
    private TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        num1 = findViewById(R.id.num1);
        num2 = findViewById(R.id.num2);
        result = findViewById(R.id.result);
    }

    public void performOperation(View view) {
        if (!validateInputs()) return;

        // Get numbers from input
        double n1 = Double.parseDouble(num1.getText().toString());
        double n2 = Double.parseDouble(num2.getText().toString());

        // Determine operation from button tag
        String operation = ((Button) view).getTag().toString();
        double output = 0;

        switch (operation) {
            case "add":
                output = n1 + n2;
                break;
            case "subtract":
                output = n1 - n2;
                break;
            case "multiply":
                output = n1 * n2;
                break;
            case "divide":
                if (n2 != 0) {
                    output = n1 / n2;
                } else {
                    result.setText("Error: Division by zero");
                    return;
                }
                break;
            case "modulus":
                output = n1 % n2;
                break;
            case "power":
                output = Math.pow(n1, n2);
                break;
        }

        // Display result
        result.setText("Result: " + output);
    }

    private boolean validateInputs() {
        if (num1.getText().toString().isEmpty()) {
            num1.setError("Enter first number");
            return false;
        }
        if (num2.getText().toString().isEmpty()) {
            num2.setError("Enter second number");
            return false;
        }
        return true;
    }
}